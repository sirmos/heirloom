# Card format

Cards are plain markdown files written to the `Heirloom Catalog` folder. One card per item.

## File name

`YYYY-MM-DD_short-title_type.md`. Use the document date if known, otherwise the file's modified date and mark it "file date". If a name exists, add `-2`, `-3`.

## Fields

| Field | Content |
|---|---|
| Title | Short plain description |
| Type | Identity, insurance, property, financial, legal, tax, medical, digital account, photo, voice memo, other |
| Original location | Full path on the NAS. The original is never moved. |
| Dates | Each date with its source (printed on document, file date, spoken in memo) and confidence |
| People | Only people named in the item or confirmed by the user |
| Summary | Five sentences at most. No sensitive values. |
| Key facts | Non-sensitive facts such as issuer, product type, coverage period |
| Sensitive values | Category plus location only. Example: "Policy number: printed on page 2 of the original. Not copied." |
| Related items | Paths of linked items and the evidence for the link |
| Accounts of events | For voice memos: narrator, timestamp, version, in the narrator's own framing |
| Action flags | Type, date, reason. Example: "Renewal date 2027-03-01 printed on page 1." |
| Confidence | High, medium, low, needs review |
| Status | Draft or confirmed |

## Gaps report

One file named `gaps-report.md`. For each expected document type, one line: Found (with card link), Not found in the folders you shared, or Unclear (with why). Use neutral wording. Never alarm.

Default expected types, replaceable by the user:

1. Identity documents
2. Life, health, home and vehicle insurance
3. Property or land titles
4. Bank, investment and pension statements
5. Will and other legal documents
6. Tax records
7. Loans and debts
8. Subscriptions and recurring payments
9. List of digital accounts and where access instructions are kept
10. Medical directives or wishes
11. Contacts for lawyer, accountant, adviser

## Ledger

`_heirloom/ledger.md` is a markdown table: source path, size, modified time, card file, status, last run date. Rerun logic depends on it. Never edit past rows except to update status.
