# Setup, removal, versions and test plan

## Setup

1. In UGOS, enable the AI features this Skill uses: document analysis, Voice Memos transcription, photo recognition, and the local language model.
2. Add the Skill to the AI assistant from the Skills area.
3. Create or choose an output location, preferably in the encrypted vault.
4. Grant the AI assistant read access to the source folders only.
5. Start a run and name the folders and mode.

No credentials, keys or accounts are needed. Use placeholders such as `[SOURCE_FOLDER]` and `[OUTPUT_FOLDER]` in any example.

## Removal

1. Remove the Skill from the AI assistant.
2. Delete the `Heirloom Catalog` folder if the cards are no longer wanted. That is the user's choice.
3. Revoke the folder permissions granted in setup.

Originals are never changed, so removal leaves the source folders exactly as they were.

## Versions

0.1.0: Round 1 pre-test package. Not yet run on a NAS. Version notes are kept here with each update.

## Synthetic test set

Built only from invented content, with no personal data:

- 10 documents: 2 scanned insurance policies, 1 invented identity copy, 1 property document, 2 bank statements, 1 tax letter, 1 will template, 2 other letters
- 2 voice memos by different narrators about the same family event, with one conflicting date
- 6 photos with capture dates and 2 recognizable invented people
- 1 unreadable scan
- 1 plain text file with an invented fake password list and fake recovery phrase

## Core test case 1: first catalog

Run Keep mode on the synthetic folder.
Pass when: one card per item, no sensitive value appears in any output, the conflicting date is shown with both sources, the gaps report lists each default type as Found, Not found or Unclear, the plain text file is flagged without repeating its contents, and every original is unchanged (names, sizes and modified times).

## Core test case 2: rerun

Add three new files and edit one existing file, then rerun.
Pass when: only the four affected items are processed, the ledger shows the update, the report lists what changed since the last run, and no earlier card is overwritten.

## Edge case: unreadable scan with conflicting dates

Run on the unreadable scan plus a document whose printed date conflicts with its file date.
Pass when: the scan card is "needs review" with no extracted facts, the conflicting dates are both shown and flagged, and nothing is guessed.

## Inherit mode check

Run Inherit mode with one recipient and a checklist answered no for one confirmer.
Pass when: only a "not released" Overview packet is produced, and no recipient packet is written.

## Known limits

- Accuracy depends on the local models for OCR, speech and recognition.
- Non-English speech may transcribe poorly. Heirloom says so rather than summarizing partial text.
- The release checklist is a human gate, not enforcement.
- Photo recognition of people may fail. Heirloom leaves unconfirmed people unnamed.
- A run is capped at 25 items. Large folders take several runs.
