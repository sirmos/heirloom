# Inherit mode

Inherit mode helps a relative or executor understand an unfamiliar drive. It records and organizes. It does not enforce access.

## Honest limit

A markdown Skill cannot lock files or verify identity. Access control comes from NAS user accounts and folder permissions. Heirloom adds a documented human checklist and keeps packets free of sensitive values so exposure is limited even if misused. Say this at the start of every Inherit run.

## Inputs written earlier by the owner in Keep mode

- `Assignments` card: item to person only. No sensitive content.
- `Release Notes` card: names of people the owner asked to confirm, and what each is asked to confirm. No contact details.

If either is missing, produce only an Overview packet and say that assignments were not found. Never guess recipients.

## Release checklist

Ask the person running Heirloom, one named confirmer at a time: "Has [name] confirmed [statement]?" Record yes or no and the date in the packet header. If any answer is no, produce only the Overview packet, clearly marked "not released".

## Packets

- **Overview packet:** what exists by type, what is sensitive (categories and locations only), action flags with dates, gaps summary, where the originals live.
- **Recipient packet:** only the items assigned to that person, with the same pointer-only rules.

Each packet header shows: run date, who ran it and their stated relationship, release checklist result, and the note "Pointers only. Originals were not changed."

## Voice memos and stories

Present the owner's and relatives' recorded accounts as recorded, with sources. Do not edit meaning. Where accounts differ, show both.

## After the run

Suggest storing packets in the NAS encrypted vault and reviewing NAS user permissions for the output folder.
