# Disclosures

## Third-party components and open source libraries

None. This Skill is markdown only and includes no code, libraries, scripts or binaries. It relies on UGOS AI capabilities and the UGREEN Skill Developer Package as provided by UGREEN, under UGREEN's terms. Source: UGREEN. Licence: as supplied by UGREEN.

## Principal functionality developed for this Hackathon

- Two-mode workflow (Keep and Inherit) for family records on a NAS
- Card format with pointer-only handling of sensitive values
- Gaps report with a default and a customizable expected-document list
- Side-by-side presentation of differing family accounts with sources
- Ledger-based incremental reruns
- Release checklist and per-recipient packets
- Failure handling table, setup, removal and a test plan with a synthetic test set

All text in this package was written during the Hackathon period.

## AI tools used and principal uses

- Claude (Anthropic): used for research on UGREEN AI NAS capabilities and gaps, for brainstorming and for drafting and reviewing this package. The author reviewed, edited and is responsible for all content. [Author: confirm this matches your actual use before submitting.]
- UGOS Skill Creation Tool: [Author: add if used, and what it was used for.]

## Data

No credentials, personal data or API keys are included. All examples use placeholders and invented content.
