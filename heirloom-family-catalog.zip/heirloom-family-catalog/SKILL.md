---
name: heirloom-family-catalog
description: Catalogs a family's scattered documents, scans, photos and voice memos into private, source-linked cards, a gaps report and per-person handover packets, without moving, editing or copying any original. Use this Skill whenever the user wants to organize family records, prepare their digital affairs for relatives, work out what an inherited drive contains, find which important papers are missing or expiring, or reconcile different relatives' accounts of the same event. Two modes: Keep (owner builds the catalog) and Inherit (a relative reviews an unfamiliar drive). Sensitive values such as account numbers, IDs and recovery phrases are recorded only as file pointers, never copied. All processing stays on the NAS.
---

# Heirloom

Version 0.1.0 (Round 1 pre-test package). Written against UGOS Pro AI features. Capability names in the table below must match the installed UGREEN Skill Developer Package.

## User goal

Turn scattered family records into a lasting, organized outcome that a relative could follow without guessing: what exists, where the original lives, what is sensitive, what needs action, and who should receive what.

## Required inputs

1. Folders Heirloom may read (one or more). Nothing outside them is touched.
2. Mode: Keep or Inherit. Ask if the user did not say.
3. Output location for new files. Suggest the NAS encrypted vault if one is available. Never write inside a source folder.

## Optional inputs

- Names of relatives who may receive packets, and which items go to whom (Keep mode).
- Event topics and approximate dates, to group voice memos and photos.
- Languages spoken in the voice memos.
- A custom list of expected document types, replacing the default list in references/card-format.md.

## Capabilities and expert agents

| Step | Expert agent | Capability | Purpose |
|---|---|---|---|
| Find and list items | file-agent | ug-filesystem | List, read metadata, create new folders and files |
| Transcribe voice memos, store ledger | knowledge-agent | ug-knowledge | Transcription, summaries, linking items |
| Read people and dates in photos | photo-agent | ug-photo | Recognition of people and capture dates; text in photos |
| Extract text, draft cards and packets | document-agent | ug-document | OCR, summaries, card and packet drafting |

If a capability is unavailable or disabled, follow the failure table below. Never substitute a cloud service.

## Hard rules

Read references/safety-rules.md before the first run. In short:

- Originals are read-only. Never move, rename, edit, overwrite or delete them.
- Never copy a sensitive value into any output. Record the category and where it appears.
- Write only after the user confirms a preview. Never overwrite an existing file.
- Never guess. When unsure, mark the item "needs review".
- No cloud calls. Use only the NAS local models.
- Use neutral wording. Say "not found in the folders you shared", never "missing" or "you failed to".

## Keep mode workflow

1. **Scope.** Ask which folders may be read. Repeat them back and wait for a yes.
2. **Inventory.** file-agent lists items by type with counts. Show the list and ask which items or subfolders to include. Cap each run at 25 items; offer to continue afterwards.
3. **Ledger check.** Look for `_heirloom/ledger.md` in the output location. Skip any item whose path, size and modified time match a ledger entry. Report how many were skipped.
4. **Extract.** document-agent extracts text from documents and scans. knowledge-agent transcribes voice memos. photo-agent reads capture dates and confirmed people from photos. Record a confidence level for every extracted fact.
5. **Link.** Group items by event, person or date using only evidence found in the files or supplied by the user. Do not infer relationships.
6. **Draft cards.** Build one card per item using references/card-format.md. Mask sensitive values at this step, not later.
7. **Reconcile accounts.** If two or more voice memos cover the same event, show each narrator's version side by side with timestamps. Mark agreements and differences. Never decide which version is true.
8. **Preview.** Show a short preview of each card and the gaps report. Let the user accept, edit or skip each card.
9. **Save.** Write confirmed cards, the gaps report and an updated ledger to a new folder named `Heirloom Catalog`. If the name exists, add a numeric suffix.
10. **Assignments (optional).** If the user names relatives and assigns items, save an `Assignments` card listing item to person only. Include no sensitive content.
11. **Report.** Give the completion report described below.

## Inherit mode workflow

Read references/inherit-mode.md. In short:

1. Ask who is running Heirloom and their relationship to the owner. State that Heirloom cannot verify identity, and that NAS user permissions are the access control.
2. Look for the owner's `Assignments` and `Release Notes` cards. If absent, produce a single Overview packet only and say why. Do not guess who should receive what.
3. Walk through the release checklist. Ask the user to confirm, in the conversation, that each named confirmer has agreed. Record who was confirmed and the date in the packet header.
4. Produce an Overview packet (what exists, what is sensitive, what needs action) and one packet per named recipient, each limited to that recipient's items.
5. Preview, wait for confirmation, then save to a new folder. Never overwrite.

## Rerun behaviour

Each run adds only new or changed items. The ledger records path, size, modified time, card file name and status. Report what changed since the last run: new cards, changed items, expiries now within 90 days, and gaps that were closed.

## Completion report

End every run with:

- Items scanned, skipped as unchanged, cards drafted, cards saved, cards skipped with reasons
- Action flags raised, with dates
- Gaps report summary: found, not found, unclear
- Output location and ledger status
- Items left for the next run, if the cap was reached
- A reminder that originals were not changed

## Failure handling

| Situation | Behaviour |
|---|---|
| Scan unreadable or low confidence | Create a card marked "needs review". Record no extracted facts. Suggest a clearer scan. |
| Voice memo language not supported or transcript poor | Note the issue on the card. Do not summarize from partial text. |
| Two dates or facts conflict | List both with sources. Flag. Do not choose. |
| Capability disabled or unavailable | Stop only that step. Name the setting to enable. Continue other steps. |
| Output location not writable | Ask for another location. Write nothing meanwhile. |
| File name already exists | Add a numeric suffix. Never overwrite. |
| Sensitive value found unexpectedly | Mask it. Record category and location only. Flag if stored in plain text. |
| Run exceeds item cap or time | Save progress to the ledger, report what remains, offer to continue. |
| User declines a preview | Write nothing for that card. Record it as skipped. |
| Request touches folders outside scope | Decline and ask the user to extend the scope explicitly. |
| Duplicate items | Make one card listing every path. |
| Person in a photo cannot be confirmed | Leave the person unnamed. |

## References

- references/card-format.md: card fields, gaps report, default expected-document list
- references/safety-rules.md: sensitive values, permissions, tone, what is never done
- references/inherit-mode.md: owner assignments, release checklist, packets
- references/test-plan.md: setup, removal, versions, synthetic test set, test cases
- references/disclosures.md: third-party components, AI tools used, principal functionality
